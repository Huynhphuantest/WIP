package Input;
import java.awt.event.*;
public class KeyHandler implements KeyListener {
    public boolean[] Key;
    public boolean[] NumPad;
    public boolean W,A,S,D,I,F,E,M,Z,CTRL,SHIFT,SPACE,ENTER;
    public boolean N1,N2,N3,N4,N5,N6,N7,N8,N9,N0;
    public KeyHandler() {
        Key = new boolean[255];
        for(boolean e : Key) {
            e = false;
        }
        NumPad = new boolean[] {
            N0,N1,N2,N3,N4,N5,N6,N7,N8,N9
        };
    }
    public void update() {
        W = Key[KeyEvent.VK_W];
        A = Key[KeyEvent.VK_A];
        S = Key[KeyEvent.VK_S];
        D = Key[KeyEvent.VK_D];
        E = Key[KeyEvent.VK_E];
        M = Key[KeyEvent.VK_M];
        F = Key[KeyEvent.VK_F];
        I = Key[KeyEvent.VK_I];
        Z = Key[KeyEvent.VK_Z];
        CTRL  = Key[KeyEvent.VK_CONTROL];
        SHIFT = Key[KeyEvent.VK_SHIFT];
        SPACE = Key[KeyEvent.VK_SPACE];
        ENTER = Key[KeyEvent.VK_ENTER];
        NumPad[1] = Key[KeyEvent.VK_1];
        NumPad[2] = Key[KeyEvent.VK_2];
        NumPad[3] = Key[KeyEvent.VK_3];
        NumPad[4] = Key[KeyEvent.VK_4];
        NumPad[5] = Key[KeyEvent.VK_5];
        NumPad[6] = Key[KeyEvent.VK_6];
        NumPad[7] = Key[KeyEvent.VK_7];
        NumPad[8] = Key[KeyEvent.VK_8];
        NumPad[9] = Key[KeyEvent.VK_9];
        NumPad[0] = Key[KeyEvent.VK_0];
    }
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        Key[code] = true;
        if(code == KeyEvent.VK_I) {
            if(I) {
                Key[code] = false;
            }
        }
        update();
    }
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_I) {
            return;
        }
        Key[code] = false;
        update();
    }
    public void keyTyped(KeyEvent e) {
        
    }
}