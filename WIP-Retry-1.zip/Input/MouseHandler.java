package Input;
import Manager.Game;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import Input.Label.AButton;
public class MouseHandler implements MouseListener, MouseMotionListener {
    public int mousex = -1, mousey = -1;
    public MouseHandler() {
        
    }

    public void mousePressed(MouseEvent e) {
        for(AButton b : AButton.getList()) {
            if(b.isPressed(e.getX(),e.getY())) b.invoke();
        }
    }

    public void mouseTyped(MouseEvent e) {

    }

    public void mouseClicked(MouseEvent e) {
        
    }

    public void mouseReleased(MouseEvent e) {
        
    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

    public void mouseMoved(MouseEvent e) {

    }

    public void mouseDragged(MouseEvent e) {
        
    }
}