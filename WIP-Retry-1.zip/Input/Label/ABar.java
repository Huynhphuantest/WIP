package Input.Label;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.BasicStroke;
import java.awt.Rectangle;
import java.awt.Canvas;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.image.BufferedImage;
public class ABar extends APanel {
    enum TextLocation {
        IN,SIDE,ON,NONE
    }
    private double Value, maxValue;
    private boolean Visible;
    private String Text;
    private double Stroke;
    private Font font;
    private FontMetrics metrics;
    private BasicStroke BasicStroke;
    private double percentage;
    private double currentPercentage;
    private double speed;
    private Color lostColor;
    private BufferedImage texture;
    private TextLocation textPlacement;
    private static ArrayList<ABar> BarList = new ArrayList<>();
    public ABar(double x, double y, double width, double height, double maxValue) {
        super(x,y,width,height);
        this.maxValue = maxValue;
        Value = maxValue;
        Visible = true;
        BarList.add(this);
        borderColor = TRANSPARENT;
        Text = "";
        percentage = (Value/maxValue);
        System.out.println(Value +" "+maxValue+" "+percentage);
        font = new Font("papyrus", Font.BOLD, 20);
        Canvas canvas = new Canvas();
        metrics = canvas.getFontMetrics(font);
        BasicStroke = new BasicStroke(0);
        Stroke = 0;
        texture = new BufferedImage((int)width,(int)height,BufferedImage.TYPE_INT_ARGB);
        textPlacement = TextLocation.SIDE;
        update();
    }
    public static void renderAll(java.awt.Graphics g) {
        BarList.forEach(e -> {e.render(g);});
    }
    public void update() {
        Graphics2D g = (Graphics2D) texture.getGraphics();
        //Inside  / Background
        g.setColor(backgroundColor);
        g.fillRect(
            (int)0,
            (int)0,
            (int)(width),
            (int)height
        );
        g.setColor(lostColor);
        g.fillRect(
            (int)0,
            (int)0,
            (int)(width*(currentPercentage)),
            (int)height
        );
        //Text   / Foreground
        g.setColor(foregroundColor);
        g.fillRect(
            (int)0,
            (int)0,
            (int)(width*(percentage)),
            (int)height
        );
        //Outside / Border
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(BasicStroke);
        g.setColor(borderColor);
        if(Stroke != 0) {
            g.drawRect(
                (int)(Stroke/4),
                (int)(Stroke/4),
                (int)(width-Stroke/2),
                (int)(height-Stroke/2)
            );
        }
        g.setColor(Color.WHITE);
        String DisplayText = Text + " "+(int)Value+"/"+(int)maxValue;
        Rectangle rect = new Rectangle((int)0,(int)0,(int)width,(int)height);
        int x2 = rect.x + (rect.width - metrics.stringWidth(DisplayText)) / 2;
        int y2 = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
        g.setFont(font);
        g.drawString(DisplayText, (int)(x2), y2);
        //Creadits : https://stackoverflow.com/users/4170242/daniel-kvist
    }
    public void render(java.awt.Graphics g) {
        if(!Visible) {
            return;
        }
        if(currentPercentage > percentage) {
            currentPercentage += speed;
            update();
        }
        if(currentPercentage < percentage) {
            currentPercentage = percentage;
            speed = 0;
            update();
        }
        g.drawImage(
            texture,
            (int)x,
            (int)y,
            (int)width,
            (int)height,
            null
        );
    }
    public void setVisible(boolean Visible) {
        this.Visible = Visible;
    }
    public void setText(String Text) {
        this.Text = Text;
    }
    public void setStroke(double Stroke) {
        this.Stroke = Stroke;
        BasicStroke = new BasicStroke((int)Stroke);
    }
    public void setFont(Font font) {
        this.font = font;
        Canvas canvas = new Canvas();
        metrics = canvas.getFontMetrics(font);
    }
    public double getValue() {
        return Value;
    }
    public double getMaxValue() {
        return maxValue;
    }
    public void setValue(double newValue) {
        this.Value = newValue;
        if(Value < 0) {
            Value = 0;
        }
        if(Value > maxValue) {
            Value = maxValue;
        }
        double lastPercentage = percentage;
        percentage = (Value/maxValue);
        speed += (percentage - lastPercentage)/20;
    }
    public void removeValue(double reValue) {
        setValue(getValue()-reValue);
    }
    public void addValue(double adValue) {
        setValue(getValue()+adValue);
    }
    public void setLostColor(Color c) {
        lostColor = c;
    }
    
    public static ArrayList<ABar> getList() {
        return BarList;
    }
}