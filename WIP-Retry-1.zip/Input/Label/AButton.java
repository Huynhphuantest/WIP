package Input.Label;

import Manager.Callback;

import java.awt.Font;
import java.awt.Color;
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Graphics2D;
import java.awt.FontMetrics;
import java.awt.BasicStroke;
import java.util.ArrayList;
import java.awt.image.BufferedImage;

public class AButton extends APanel {
    private Callback method;
    private boolean Visible;
    private String Text;
    private double Stroke;
    private Font font;
    private FontMetrics metrics;
    private BasicStroke BasicStroke;
    private BufferedImage texture;
    protected static ArrayList<AButton> ButtonList = new ArrayList<>();
    public AButton(double x, double y, double width, double height) {
        super(x,y,width,height);
        Visible = true;
        borderColor = TRANSPARENT;
        Text = "";
        font = new Font("Serif", Font.PLAIN, 12);
        Canvas canvas = new Canvas();
        metrics = canvas.getFontMetrics(font);
        BasicStroke = new BasicStroke(0);
        Stroke = 0;
        ButtonList.add(this);
        texture = new BufferedImage((int)width, (int)height,BufferedImage.TYPE_INT_ARGB);
        update();
    }
    public AButton(double x, double y, double width, double height, Callback method) {
        this(x,y,width,height);
        this.method = method;
    }
    public void update() {
        Graphics g = texture.getGraphics();
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(BasicStroke);
        //Inside  / Background
        g.setColor(backgroundColor);
        g.fillRect(
            (int)0,
            (int)0,
            (int)width,
            (int)height
        );
        //Outside / Border
        g.setColor(borderColor);
        if(Stroke != 0) {
            g.drawRect(
                (int)0,
                (int)0,
                (int)(width-Stroke/2),
                (int)(height-Stroke/2)
            );
        }
        //Text   / Foreground
        g.setColor(foregroundColor);
        Rectangle rect = new Rectangle((int)0,(int)0,(int)width,(int)height);
        int x2 = rect.x + (rect.width - metrics.stringWidth(Text)) / 2;
        int y2 = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
        g.setFont(font);
        g.drawString(Text, x2, y2);
        //Creadits : https://stackoverflow.com/users/4170242/daniel-kvist
    }
    public void render(java.awt.Graphics g) {
        if(!Visible) {
            return;
        }
        g.drawImage(
            texture,
            (int)x,
            (int)y,
            (int)width,
            (int)height,
            null
        );
    }
    public void invoke() {
        if(method == null) {
            return;
        }
        method.call();
        update();
    }

    public void setVisible(boolean Visible) {
        this.Visible = Visible;
    }
    public void setText(String Text) {
        this.Text = Text;
        update();
    }
    public void setStroke(double Stroke) {
        this.Stroke = Stroke;
        BasicStroke = new BasicStroke((int)Stroke);
        update();
    }
    public void setFont(Font font) {
        this.font = font;
        Canvas canvas = new Canvas();
        metrics = canvas.getFontMetrics(font);
        update();
    }

    public void setMethod(Callback method) {
        this.method = method;
    }
    public boolean isPressed(double PressedX, double PressedY) {
        return (new Rectangle((int) x,(int) y,(int) width,(int) height)).contains((int) PressedX,(int) PressedY);
    }
    
    public static ArrayList<AButton> getList() {
        return ButtonList;
    }
}