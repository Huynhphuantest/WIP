package AUtility;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.util.*;
import java.io.*;
public class Util {
    public static BufferedImage rotate(BufferedImage Texture) {
        double angle = 120;
        BufferedImage bimg = Texture;
        double 
            sin = Math.abs(Math.sin(Math.toRadians(angle))),
            cos = Math.abs(Math.cos(Math.toRadians(angle)));
        double 
            w = bimg.getWidth(),
            h = bimg.getHeight(),
            neww = (int) Math.floor(w*cos + h*sin),
            newh = (int) Math.floor(h*cos + w*sin);
        BufferedImage rotated = new BufferedImage((int)(neww), (int)(newh), bimg.getType());
        Graphics2D graphic = rotated.createGraphics();
        graphic.translate((neww-w)/2, (newh-h)/2);
        graphic.rotate(Math.toRadians(angle), w/2, h/2);
        graphic.drawRenderedImage(bimg, null);
        graphic.dispose();
        for(int i = 0; i < rotated.getHeight(); i++) {
            for(int j = 0; j < rotated.getWidth(); j++) {
                if(rotated.getRGB(i,j) != 0) {
                    rotated.setRGB(i,j,new java.awt.Color(0,0,0,142).getRGB());
                }
            }
        }
        return rotated;
        //Credits : https://stackoverflow.com/users/4455670/vinz
    }
    public static double random(double min, double max) {
        return new Random().nextDouble(max-min)+min;
    }
    //File
    public static ArrayList<String> openFile(String url) {
        try {
            ArrayList<String> list = new ArrayList<>();
            BufferedReader rd = new BufferedReader(new FileReader(url));
            String line;
            while((line = rd.readLine()) != null) {
                list.add(line);
            }
            return list;
        } catch(IOException e){
            e.printStackTrace();
        }
        return new ArrayList<String>();
    }
}