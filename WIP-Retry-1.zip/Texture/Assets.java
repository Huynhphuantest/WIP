package Texture;
import java.awt.image.*;
import java.io.*;
import java.awt.Color;    
import javax.imageio.*;
import javax.sound.sampled.*;
import java.awt.Graphics;
public class Assets {
    public static void init() {
        
    }
    public static BufferedImage Load(String path) {
        try {
            return ImageIO.read(new File(path));
            } catch(IOException e) {
            e.printStackTrace();
            System.exit(1);
            }
        return null;
    }
    public static BufferedImage LoadDecor(String path) {
        return Load("Texture/Decoration/"+path+".png");
    }
    public static BufferedImage LoadEntity(String path) {
        return Load(("Texture/Entity/"+path+".png"));
    }
    public static BufferedImage LoadProjectiles(String path) {
        return Load(("Texture/Entity/Projectiles/"+path+".png"));
    }
    public static BufferedImage LoadButton(String path) {
        return Load("Texture/Button/"+path+".png");
    }
    public static BufferedImage LoadTile(String path) {
        return Load("Texture/Tile/"+path+".png");
    }
    public static BufferedImage LoadLabel(String path) {
        return Load("Texture/Label/"+path+".png");
    
    }
    public static BufferedImage LoadItem(String path) {
        return Load("Texture/Item/"+path+".png");
    }
    public static void playTile(String path) {
        
    }
    public static File getFile(String path) {
        try {
            return new File(path);
            } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
            }
        return null;
    }
    public static File LoadFile(String path){
        return getFile("Sound/Gardening/"+path+".wav");
    }
}