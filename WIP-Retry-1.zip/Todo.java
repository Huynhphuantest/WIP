public class Todo {
    public static void send() {
        L("Passive Skill");
        L("Item");
    }
    public static void L(String t) {
        System.out.println("Todo : "+t);
    }
}