package Manager;
public interface Callback {
    public void call();
}