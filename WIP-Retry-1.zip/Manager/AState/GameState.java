package Manager.AState;

import AObject.Object;
import AObject.ATile.Natural.*;
import AObject.AEntity.Neutral.*;
import Input.Label.*;
import Manager.Game;
import Render.Screen;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class GameState extends State {
    private Player player;
    private int screenWidth, screenHeight;
    private int CircleSize;
    private Color InnerColor, OuterColor;
    public ABar health, stamina, energy;
    private BufferedImage UI;
    public GameState() {
        Screen screen = Game.getGame().getScreen();
        screenWidth = (int) screen.getWidth();
        screenHeight = (int) screen.getHeight();
        player = new Player(200,200);
        CircleSize = 150;
        OuterColor = new Color(117, 82, 21);
        InnerColor = new Color(255, 219, 156);
        int size = 100;
        for(int y = -size; y < size; y++) {
            for(int x = -size; x < size; x++) {
                new Grass0(x,y);
            }
        }
        UI = new BufferedImage(CircleSize*3, CircleSize*3,BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = (java.awt.Graphics2D) UI.getGraphics();
        g.setColor(OuterColor);
        g.fillOval(0,0,CircleSize,CircleSize);
        g.fillRoundRect(15,23,CircleSize,(int)(CircleSize/1.5)+50,50,50);
        g.setColor(InnerColor);
        g.fillOval(5,5,CircleSize-10,CircleSize-10);
        health = new ABar(CircleSize+25,CircleSize/2-20,CircleSize*2,65,player.getMaxHealth());
        health.setForegroundColor(Color.YELLOW);
        health.setBackgroundColor(new Color(168, 50, 29));
        health.setBorderColor(OuterColor);
        health.setStroke(10);
        health.setLostColor(new Color(195, 201, 0));
        stamina = new ABar(CircleSize+25,(CircleSize/2-20)*2,(CircleSize*2.75),35,player.getMaxStamina());
        stamina.setForegroundColor(Color.ORANGE);
        stamina.setBackgroundColor(Color.BLACK);
        stamina.setBorderColor(OuterColor);
        stamina.setStroke(10);
        energy = new ABar(CircleSize+25,(CircleSize/2-22)*3-30,CircleSize,35,player.getMaxEnergy());
        energy.setForegroundColor(Color.CYAN);
        energy.setBackgroundColor(Color.BLACK);
        energy.setBorderColor(OuterColor);
        energy.setStroke(10);
        energy.setLostColor(new Color(73, 173, 168));
        Manager.Time.invoke(
            () -> {
                AObject.AEntity.Entity.updateLoader();
            },1
        );
    }
    public void update() {
        Object.updateAll();
    }
    public void render(java.awt.Graphics g) {
        Object.renderAll(g);
        ABar.renderAll(g);
        g.drawImage(UI,10,10,CircleSize*3,CircleSize*3,null);
    }
    public Player getPlayer() {
        return player;
    }
    public ABar getHealth() {
        return health;
    }
}