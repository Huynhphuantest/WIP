package Manager.AState;
public abstract class State {
    private static State currentState;
    public void update() {}
    public void render(java.awt.Graphics g) {}
    public static void setCurrentState(State s) {
        currentState = s;
    }
    public static State getCurrentState() {
        return currentState;
    }
    public static GameState getGameState() {
        if(currentState instanceof GameState) {
            return (GameState) currentState;
        }
        return null;
    }
}