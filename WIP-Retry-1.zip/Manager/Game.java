package Manager;
//My classes
import Render.Screen;
import Input.KeyHandler;
import Input.MouseHandler;
import Manager.AState.State;
//Built-in classes
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.Color;
public class Game implements Runnable {
    private double width,height;
    private Screen screen;
    private KeyHandler keyH;
    private MouseHandler mouH;
    private static Game g;
    private BufferStrategy bs;
    public double deltaTime = 1 / 60;
    public boolean Mobile;
    public Game() {
        width = 1440; //1440
        height = 922; //922
        screen = new Screen(width,height);
        try{Thread.sleep(10);} catch(InterruptedException ignore){};
        start();
        Mobile = false;
    }
    public void start() {
        init();
        State.setCurrentState(new Manager.AState.GameState());
        Thread thread = new Thread(this);
        thread.start();
    }
    public void init() {
        keyH = new KeyHandler();
        mouH = new MouseHandler();
        screen.getCanvas().addKeyListener(keyH);
        screen.getCanvas().addMouseListener(mouH);
        screen.getCanvas().addMouseMotionListener(mouH);
        g = this;
    }
    public void update() {
        State.getCurrentState().update();
    }
    public void render() {
        bs = screen.getCanvas().getBufferStrategy();if(bs == null)
        {screen.getCanvas().createBufferStrategy(2);return;}Graphics g = bs.getDrawGraphics();
        //Clearing
        g.setColor(new Color(30,30,30));
        g.fillRect(0,0,screen.getWidth(),screen.getHeight());
        //Done Clearing
        State.getCurrentState().render(g);
        //End Render
        g.dispose();
        bs.show();
    }
    public void run() {
        double frame = (int) System.currentTimeMillis();
        long fps = 60;
        double timePerTick=1000000000/fps;
        double delta=0;
        long now;
        long last=System.nanoTime();
        double times=0;
        double ticks=0;
        while(true) {
            if(System.currentTimeMillis()-frame>=1000){
                frame=(int)System.currentTimeMillis();
            }
            now = System.nanoTime();delta += (now - last) / timePerTick;times += now-last;last=now;frame++;if(delta>=1){
            //Code Here
            render();
            update();
            //No code here screw you
            delta-=1;
            frame = 0;
            ticks++;
            }
            if(times >= 1e9) {
                String currentMem = Runtime.getRuntime().totalMemory()+"MB";
                String maxMem = Runtime.getRuntime().maxMemory()+"MB";
                screen.setTitle("FPS : "+ticks+" Current Heap Storage : "+currentMem+"/"+maxMem);
                deltaTime = (1 / ticks);
                times = 0;
                ticks = 0;
            }
        }
    }
    //Getters
    public KeyHandler getKeyHandler() {
        return keyH;
    }
    public Screen getScreen() {
        return screen;
    }
    public double getDeltaTime() {
        return deltaTime;
    }
    public static Game getGame() {
        return g;
    }
}