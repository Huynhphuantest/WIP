package Manager;
import java.util.ArrayList;
public class Looper implements Runnable {
    private String name;
    private Callback method;
    private long repeatTime;
    private Thread thread;
    private boolean run;
    private static ArrayList<Looper> LoopList = new ArrayList<>();
    private static ArrayList<Looper> remove = new ArrayList<>();
    public Looper(String name, Callback method,long repeatTime) {
        this.name = name;
        this.method = method;
        this.repeatTime = repeatTime;
        run = true;
        LoopList.add(this);
        thread = new Thread(this);
        thread.start();
    }
    public void run() {
        while(run) {
            method.call();
            try {
            Thread.sleep(repeatTime);
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void stop() {
        run = false;
    }
    public static void stopLoop(String name) {
        for(Looper e : LoopList) {
            if(e.name == name) {
                e.stop();
                remove.add(e);
            }
        }
        LoopList.removeAll(remove);
        remove.clear();
    }
}