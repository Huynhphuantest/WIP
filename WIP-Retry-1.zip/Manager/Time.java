package Manager;
public class Time  {
    public static void invoke(Callback callback, double second) {
        Thread thread = new Thread() {
            public void run() {
                try {
                    Thread.sleep((long)(second*1000));
                } catch(Exception e) {
                    e.printStackTrace();
                }
                callback.call();
            }
        };
        thread.start();
    }
    public static void invokeRepeat(Callback callback, String name, double frequency) {
        new Looper(name,callback,(long)frequency*1000);
    }
    public static void stop(String name) {
        Looper.stopLoop(name);
    }
}