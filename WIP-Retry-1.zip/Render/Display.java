package Render;
import java.awt.Canvas;
import java.awt.Dimension;
public class Display extends Canvas {
    private Dimension screenSize;
    public Display(Dimension screenSize) {
        this.screenSize = screenSize;
        this.setPreferredSize(screenSize);
        this.setFocusable(true);
        this.setVisible(true);
    }
}