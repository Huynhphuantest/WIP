package Render;
import java.awt.Graphics;
import java.awt.Color;
public abstract class MyPanel {
    protected double x,y,width,height;
    protected Color backgroundColor, foregroundColor, borderColor; 
    public MyPanel(double x, double y,double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        backgroundColor = Color.BLACK;
        foregroundColor = Color.RED;
        borderColor = Color.WHITE;
    }
    public void render(Graphics g) {
        g.fillRect((int)x,
                   (int)y,
                   (int)width,
                   (int)height);
    }
    public double getX() {
        return x;
    }
    public double getY() {
        return y;
    }
    public double getWidth() {
        return width;
    }
    public double getHeight() {
        return height;
    }
    public void setX(double x) {
        this.x = x;
    }
    public void setY(double y) {
        this.y = y;
    }
    public void setWidth(double width) {
        this.width = width;
    }
    public void setHeight(double height) {
        this.height = height;
    }
    public void setLocation(double x, double y) {
        setX(x);
        setY(y);
    }
    public void setSize(double width, double height) {
        setWidth(width);
        setHeight(height);
    }
    public void setBackgroundColor(Color c) {
        backgroundColor = c;
    }
    public void setForegroundColor(Color c) {
        foregroundColor = c;
    }
    public void setBorderColor(Color c) {
        borderColor = c;
    }
}