package Render;
import java.awt.Dimension;
import javax.swing.JFrame;
public class Screen extends JFrame {
    private Display canvas;
    private Dimension screenSize;
    public Screen(double width, double height) {
        screenSize = new Dimension((int)width,(int)height);
        canvas = new Display(screenSize);
        //Screen Work
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(canvas);
        this.setFocusable(true);
        this.setVisible(true);
        this.pack();
    }
    public Display getCanvas() {
        return canvas;
    }
}