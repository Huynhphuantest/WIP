package Collections;
public class Vector2 {
    private double x,y;
    public final static Vector2 zero = new Vector2(0,0);
    public Vector2(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    public double getX() {
        return x;
    }
    public double getY() {
        return y;
    }
    public void setX(double x) {
        this.x = x;
    }
    public void setY(double y) {
        this.y = y;
    }
    public String toString() {
        return ("Vector2[X="+x+",Y="+y+"]");
    }
    //Utility Setters

    public void addX(double x) {
        this.x += x;
    }
    public void addY(double y) {
        this.y += y;
    }
    public void minusX(double x) {
        this.x -= x;
    }
    public void minusY(double y) {
        this.y -= y;
    }
    public void setTo(Vector2 Target) {
        this.x = Target.getX();
        this.y = Target.getY();
    }
    public void toDefault() {
        this.x = zero.getX();
        this.y = zero.getY();
    }
    
    //Calculate Method

    public double distantTo(Vector2 Target) {
        return Math.abs(
            (Target.getX() - x) +
            (Target.getY() - y)
        );
    }
    public double distantTo(double x, double y) {
        return distantTo(new Vector2(x,y));
    }
}