package AObject.AItem;

import AObject.AEntity.Entity;

import java.util.ArrayList;

public abstract class Item extends Entity {
    public static double DEFAULT_SIZE = 64;
    protected static ArrayList<Item> ItemList = new ArrayList<>();
    public Item(double x, double y) {
        super(x*DEFAULT_SIZE,y*DEFAULT_SIZE,DEFAULT_SIZE,DEFAULT_SIZE);
        ItemList.add(this);
    }
    public void pickUp( ) {
        remove();
    }
    public static ArrayList<Item> getItemList( ) {
        return ItemList;
    }
}