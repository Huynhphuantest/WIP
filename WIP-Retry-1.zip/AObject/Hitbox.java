package AObject;
import java.awt.Rectangle;
public class Hitbox extends Rectangle {
    public Hitbox(double x, double y, double width, double height) {
        super(
            (int)x,
            (int)y,
            (int)width,
            (int)height
        );
    }
    
    public boolean intersects(double x,double y,double width,double height) {
        return super.intersects(
            new Rectangle((int)x,(int)y,(int)width,(int)height)
        );
    }
    public boolean intersects(Hitbox x) {
        return super.intersects(x);
    }

    public void setLocation(double x, double y) {
        this.x = (int) x;
        this.y = (int) y;
    }
}