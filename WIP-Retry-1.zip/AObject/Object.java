package AObject;

import AObject.AEntity.Entity;
import AObject.AEntity.Neutral.Player;
import AObject.ATile.Tile;
import AObject.ATile.Decoration;
import Collections.Vector2;
import Manager.Callback;

import java.util.ArrayList;
import java.awt.image.BufferedImage;

public abstract class Object {
    public static double DEFAULT_ACCELERATION_SPEED = 5;
    protected double x,y,width,height;
    protected double Acceleration;
    protected Vector2 Velocity;
    protected double LaunchAngle;
    protected boolean Temporary, Loaded;
    protected BufferedImage Texture;
    protected ArrayList<String> TagList = new ArrayList<>();
    private static ArrayList<Object> ObjectList = new ArrayList<>();
    private static ArrayList<Object> removeList = new ArrayList<>();
    private static ArrayList<Callback> renderLast = new ArrayList<>();
    private static ArrayList<Callback> removeMed = new ArrayList<>();
    public Object(double x, double y, double width, double height) {
        Temporary = (x == 0 && y == 0);
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        Velocity = Vector2.zero;
        Loaded = true;
        double px = 100;
        double py = 100;
        if(!(this instanceof Player)) {
            if( getX() + px + getWidth()  < 0 || getX() > Manager.Game.getGame().getScreen().getWidth()   + getWidth() ||
                getY() + py + getHeight() < 0 || getY() > Manager.Game.getGame().getScreen().getHeight()  + getHeight()
                ) {
                    Loaded = false;
                } else {
                Loaded = true;
            }
        }
        if(!Temporary && this instanceof Object) {
            ObjectList.add(this);
        }
    }

    public static void updateAll( ) {
        for(Object e : ObjectList) {
            if(e.Velocity.getX() != 0.0) {
                System.out.println(Vector2.zero);
                e.Acceleration += DEFAULT_ACCELERATION_SPEED;
                
            }
            if(e instanceof Entity || e instanceof Tile || !e.Loaded) {
                continue;
            }
            e.update();
        }
        Entity.updateAll();
        Tile.updateAll();
        Tile.updateAllB();
        if(removeList.size() != 0) {
            for(Object e : removeList) {
                if(e instanceof Entity) {
                    Entity.getEntityList().remove(e);
                }
                if(e instanceof Tile) {
                    Tile.getTileList().remove(e);
                }
                if(e instanceof Decoration) {
                    Tile.getDecorList().remove(e);
                }
            }
            ObjectList.removeAll(removeList);
            removeList.clear();
        }
    }
    public static void renderAll(java.awt.Graphics g) {
        for(Object e : ObjectList) {
            if(e instanceof Entity || e instanceof Tile || !e.Loaded) {
                continue;
            }
            e.render(g);
        }
        Tile.renderAll(g);
        Entity.renderAll(g);
        Tile.renderAllB(g);
        renderLast.forEach((Callback e) -> {e.call();});
        removeMed.forEach((Callback e) -> {renderLast.remove(e);});
        removeMed.clear();
    }
    public static void updateLoader() {
        int safeZone = 0;
        double px = Player.player.getX();
        double py = Player.player.getY();
        for(Object e : ObjectList) {
            if(e.getX() + px + e.getWidth()  < 0 + safeZone || e.getX() > Manager.Game.getGame().getScreen().getWidth()   + e.getWidth()  - safeZone * 2 ||
               e.getY() + py + e.getHeight() < 0 + safeZone || e.getY() > Manager.Game.getGame().getScreen().getHeight()  + e.getHeight() - safeZone * 2
            ) {
                e.Loaded = false;
            } else {
                e.Loaded = true;
                e.loadedUpdate();
            }
        }
    }

    public void update( ) { }
    public void render(java.awt.Graphics g) {
        g.drawImage(
            Texture,
            (int)getX(),
            (int)getY(),
            (int)getWidth(),
            (int)getHeight(),
            null
        );
    }
    public void loadedUpdate() {}

    public double getX( ) {
        return x-Player.player.getOffsetX();
    }
    public double getY( ) {
        return y-Player.player.getOffsetY();
    }
    public double getRealX( ) {
        return x;
    }
    public double getRealY( ) {
        return y;
    }
    public double getWidth( ) {
        return width;
    }
    public double getHeight( ) {
        return height;
    }

    public void remove( ) {
        removeList.add(this);
    }
    public void move(double x, double y) {
        this.x += -x*Manager.Game.getGame().getDeltaTime();
        this.y += -y*Manager.Game.getGame().getDeltaTime();
    }
    public void launch(double ForceX, double ForceY) {
        Velocity.addX(ForceX);
        Velocity.addY(ForceY);
    }
    public void addTag(String tag) {
        TagList.add(tag);
    }

    public static ArrayList<Object> getObjectList( ) {
        return ObjectList;
    }

    //Utility Drawer

    public static void drawImage(java.awt.Graphics g,java.awt.image.BufferedImage img, double x, double y, double width, double height) {
        g.drawImage(
            img,
            (int)x,
            (int)y,
            (int)width,
            (int)height,
            null
        );
    }
    public static void renderLast(Callback method,double sec) {
        renderLast.add(method);
        Manager.Time.invoke(
            () -> {
                removeMed.add(method);
            },sec
        );
    }
}