package AObject.AEntity;

import AObject.ASkill.Skill;
import java.lang.reflect.Constructor;

import java.util.ArrayList;

public abstract class Creature extends Entity {
    public double DEFAULT_STAMINA = 600, DEFAULT_ENERGY = 30,DEFAULT_DAMAGE = 5, DEFAULT_SPEED = 30, DEFAULT_ATTACK_SPEED = 0.5, DEFAULT_DEFENSE = 70;
    
    protected double Health, MaxHealth, Stamina, MaxStamina, Energy, MaxEnergy, Speed, Damage, AttackSpeed, Defense;
    protected ArrayList<Skill> SkillSlot = new ArrayList<>();
    public Creature(double x, double y, double width, double height, double MaxHealth) {
        super(x,y,width,height);
        this.MaxHealth = MaxHealth;
        Health = MaxHealth;
        MaxStamina = DEFAULT_STAMINA;
        Stamina = MaxStamina;
        MaxEnergy = DEFAULT_ENERGY;
        Energy = MaxEnergy;
        Speed = DEFAULT_SPEED;
        Damage = DEFAULT_DAMAGE;
        AttackSpeed = DEFAULT_ATTACK_SPEED;
        Defense = DEFAULT_DEFENSE;
    }

    //Getters
    public double getMaxHealth( ) {
        return MaxHealth;
    }
    public double getHealth( ) {
        return Health;
    }
    public double getMaxStamina() {
        return MaxStamina;
    }
    public double getStamina() {
        return Stamina;
    }
    public double getMaxEnergy() {
        return MaxEnergy;
    }
    public double getEnergy() {
        return Energy;
    }
    public double getSpeed( ) {
        return Speed;
    }
    public double getDamage( ) {
        return Damage;
    }
    public double getAttackSpeed( ) {
        return AttackSpeed;
    }
    public double getDefense() {
        return Defense;
    }

    //Setters
    public void getAttacked(Creature dealer) {
        double DamageDeal = calculateDamage(dealer.getDamage(), getDefense());
        Health = getHealth() - DamageDeal < 0 ? -1 : getHealth() - DamageDeal; 
        if(getHealth() == 0) {
            //TODO - Die
        }
    }
    public void getAttacked(double damage) {
        double DamageDeal = calculateDamage(damage, getDefense());
        Health = getHealth() - DamageDeal < 0 ? -1 : getHealth() - DamageDeal; 
        if(getHealth() == 0) {
            //TODO - Die
        }
    }
    public void setSpeed(double newSpeed) {
        Speed = newSpeed;
    }
    public void setEnergy(double newEnergy) {
        Energy = newEnergy;
        if(Energy > MaxEnergy) {
            Energy = MaxEnergy;
        }
        if(Energy < 0) {
            Energy = 0;
        }
    }
    public void setStamina(double newStamina) {
        Stamina = newStamina;
        if(Stamina > MaxStamina) {
            Stamina = MaxStamina;
        }
        if(Stamina < 0) {
            Stamina = 0;
        }
    }

    public static double calculateDamage(double baseDmg, double OppDef) {
        return baseDmg * ((1 + baseDmg / 25) / (1 + OppDef / 25));
    }

    public static void addActiveSkill(Creature Owner, String... Name) {
        for(String e : Name) {
            try {
                Class<?> c = Class.forName("AObject.ASkill.Active."+e);
                Constructor<?> cons = c.getConstructor(Creature.class);
                Skill s = (Skill) cons.newInstance(Owner);
                Owner.SkillSlot.add(s);
            } catch(Exception v) {
                System.out.println("Invalid skill, try again");
            }
        }
    }
}