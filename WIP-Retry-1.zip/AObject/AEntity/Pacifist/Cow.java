package AObject.AEntity.Pacifist;
import AObject.AEntity.Creature;
public class Cow extends Creature {
    public Cow(double x, double y) {
        super(x,y,100,100,50);
    }
}