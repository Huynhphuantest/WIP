package AObject.AEntity.Neutral;

import AObject.AEntity.Creature;
import Input.KeyHandler;
import Input.Label.AButton;
import Texture.Assets;
import AObject.AItem.Item;
import Manager.Game;
import Manager.AState.State;

import java.awt.Color;

public class Player extends Creature {
    private KeyHandler Key;
    private Game game;
    private double loadingIn;
    protected double OffsetX, OffsetY;
    protected AButton S1, S2, S3, S4, S5;
    public static Player player;
    private double staminaRegen;
    public Player(double x, double y) {
        super(x,y,100,100,100);
        player = this;
        Speed = 60;
        Damage = 10;
        Defense = 10;
        AttackSpeed = 0.3;
        loadingIn = 0;
        game = Game.getGame();
        Key = Manager.Game.getGame().getKeyHandler();
        double size = 70;
        S1 = new AButton(200,300,size,size);
        Color border = new Color(25, 194, 157);
        Color background = new Color(140, 140, 140);
        staminaRegen = 0;
        S1.setBorderColor(border);
        S1.setStroke(1.5);
        S1.setForegroundColor(Color.WHITE);
        S1.setFont(new java.awt.Font("Serif",java.awt.Font.PLAIN, 36));
        S1.setText("1");
        S1.setMethod(
            () -> {
                S1.setBackgroundColor(new Color(125, 0, 0));
                Manager.Time.invoke(
                    () -> {S1.setBackgroundColor(background);}, 2);
            }
        );
        S1.setBackgroundColor(background);
        addActiveSkill(this,"Dash");
    }
    
    public void update() {
        //Movement
        double CSpeed = Speed;
        double SpeedX = 0;
        double SpeedY = 0;
        if(Key.SHIFT && Energy > 0) {
            CSpeed *= 2;
        }
        if(staminaRegen < 0) {
            setEnergy(Energy + 0.3);
            State.getGameState().energy.setValue(Energy);
        } else {
            staminaRegen -= Manager.Game.getGame().getDeltaTime();
        }
        if(Key.W) {
            SpeedY = CSpeed;
        }
        if(Key.S) {
            SpeedY = -CSpeed;
        }
        if(Key.A) {
            SpeedX = CSpeed;
        }
        if(Key.D) {
            SpeedX = -CSpeed;
        }
        move(SpeedX,SpeedY);
        if(Math.abs(SpeedX) > 1 || Math.abs(SpeedY) > 1) {
            loadingIn+=game.getDeltaTime();
            if(loadingIn > 2.5) {
                loadingIn = 0;
                updateLoader();
            }
        }
        //Extra function
        if(Key.E) {
            for(Item e : Item.getItemList()) {
                
            }
        }
        //Skill
        if(Key.NumPad[0] || Key.SPACE) {
            SkillSlot.get(0).use();
        }
    }
    public void render(java.awt.Graphics g) {
        super.render(g);
        S1.render(g);
    }

    public double getX() {
        return x;
    }
    public double getY() {
        return y;
    }
    public double getOffsetX() {
        return OffsetX;
    }
    public double getOffsetY() {
        return OffsetY;
    }
    @Override
    public void getAttacked(Creature dealer) {
        double DamageDeal = calculateDamage(dealer.getDamage(), getDefense());
        Health = getHealth() - DamageDeal < 0 ? -1 : getHealth() - DamageDeal; 
        if(getHealth() == 0) {
            //TODO - Die
        }
        State.getGameState().health.removeValue(DamageDeal);
    }
    @Override
    public void getAttacked(double damage) {
        double DamageDeal = calculateDamage(damage, getDefense());
        Health = getHealth() - DamageDeal < 0 ? -1 : getHealth() - DamageDeal; 
        if(getHealth() == 0) {
            //TODO - Die
        }
        State.getGameState().getHealth().setValue(Health);
    }
    public void move(double x, double y) {
        double LastX = OffsetX;
        double LastY = OffsetY;
        OffsetX += -x*Manager.Game.getGame().getDeltaTime();
        OffsetY += -y*Manager.Game.getGame().getDeltaTime();
        @SuppressWarnings("unused")
        boolean Moving;
        if(Moving = (LastX != OffsetX || LastY != OffsetY)) {
            if(Key.SHIFT) {
                setEnergy(Energy -= 0.1);
                State.getGameState().energy.setValue(Energy);
                staminaRegen = 2;
            }
            if(LastX > OffsetX) {
                if(Sprite >= Left.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Left.get(Sprite);
            }
            if(LastX < OffsetX) {
                if(Sprite >= Right.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Right.get(Sprite);
            }
            if(LastY > OffsetY) {
                if(Sprite >= Up.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Up.get(Sprite);
            }
            if(LastY < OffsetY) {
                if(Sprite >= Down.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Down.get(Sprite);
            }
            SpriteCounter+=Manager.Game.getGame().getDeltaTime();
            if(SpriteCounter > 0.3) {
                Sprite++;
                SpriteCounter = 0;
            }
        } else {
            Texture = Down.get(0);
        }
    }
}