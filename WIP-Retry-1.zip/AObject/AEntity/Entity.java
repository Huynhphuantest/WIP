package AObject.AEntity;

import AObject.Object;
import AObject.Hitbox;
import Texture.Assets;

import java.util.ArrayList;
import java.awt.image.BufferedImage;
import java.lang.StackWalker.Option;
import java.io.File;

public abstract class Entity extends Object {
    protected ArrayList<BufferedImage> Up,Down,Right,Left;
    protected int Sprite;
    protected double SpriteCounter;
    protected Hitbox hitbox;
    private static ArrayList<Class<?>> autoTexture = new ArrayList<>();
    private static ArrayList<ArrayList<ArrayList<BufferedImage>>> savedTexture = new ArrayList<>();
    private static ArrayList<Entity> EntityList = new ArrayList<>();
    public Entity(double x, double y, double width, double height) {
        super(x,y,width,height);
        hitbox = new Hitbox(x,y,width,height);
        Class<?> clazz = this.getClass().asSubclass(this.getClass());
        System.out.println("Entity/"+clazz.getSimpleName()+"/"+clazz.getSimpleName()+".png");
        if(!(autoTexture.contains(clazz))) {
            autoTexture(clazz);
            initTexture(clazz);
        }
        Sprite = 0;
        SpriteCounter = 0;
        Up    = savedTexture.get(autoTexture.indexOf(clazz)).get(0);
        Down  = savedTexture.get(autoTexture.indexOf(clazz)).get(1);
        Right = savedTexture.get(autoTexture.indexOf(clazz)).get(2);
        Left  = savedTexture.get(autoTexture.indexOf(clazz)).get(3);
        Texture = Down.get(Sprite);
        if(!Temporary && (this instanceof Entity || this instanceof Creature)) {
            EntityList.add(this);
        }
    }

    public static void updateAll( ) {
        for(Entity e : EntityList) {
            if(!e.Loaded) {
                continue;
            }
            e.update();
        }
    }
    public static void renderAll(java.awt.Graphics g) {
        for(Entity e : EntityList) {
            if(!e.Loaded) {
                continue;
            }
            e.render(g);
        }
    }

    public static void autoTexture(Class<?> e) {
        autoTexture.add(e);
    }

    public static void initTexture(Class<?> e) {
        {
            ArrayList<ArrayList<BufferedImage>> AllTexture = new ArrayList<>(); 
            ArrayList<BufferedImage> 
                Up = new ArrayList<>(),
                Down = new ArrayList<>(),
                Right = new ArrayList<>(),
                Left = new ArrayList<>();
            int i = 0;
            String name = e.getSimpleName();
            while(new File("Texture/Entity/"+name+"/"+name+"U"+i+".png").exists()) {
                Up.add(Assets.LoadEntity(name+"/"+name+"U"+i));
                i++;
            }
            i = 0;
            while(new File("Texture/Entity/"+name+"/"+name+"D"+i+".png").exists()) {
                Down.add(Assets.LoadEntity(name+"/"+name+"D"+i));
                i++;
            }
            i = 0;
            while(new File("Texture/Entity/"+name+"/"+name+"R"+i+".png").exists()) {
                Right.add(Assets.LoadEntity(name+"/"+name+"R"+i));
                i++;
            }
            i = 0;
            while(new File("Texture/Entity/"+name+"/"+name+"L"+i+".png").exists()) {
                Left.add(Assets.LoadEntity(name+"/"+name+"L"+i));
                i++;
            }
            AllTexture.add(Up);
            AllTexture.add(Down);
            AllTexture.add(Right);
            AllTexture.add(Left);
            savedTexture.add(AllTexture);
        }
    }

    public static ArrayList<Entity> getEntityList() {
        return EntityList;
    }

    @Override
    public void move(double x, double y) {
        double LastX = getRealX();
        double LastY = getRealY();
        super.move(x,y);
        @SuppressWarnings("unused")
        boolean Moving;
        if(Moving = (LastX != getRealX() || LastY != getRealY())) {
            if(LastX > getRealX()) {
                if(Sprite >= Left.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Left.get(Sprite);
            }
            if(LastX < getRealX()) {
                if(Sprite >= Right.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Right.get(Sprite);
            }
            if(LastY > getRealY()) {
                if(Sprite >= Up.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Up.get(Sprite);
            }
            if(LastY < getRealY()) {
                if(Sprite >= Down.size()) {
                    Sprite = 0;
                    SpriteCounter = 0;
                }
                Texture = Down.get(Sprite);
            }
            SpriteCounter+=Manager.Game.getGame().getDeltaTime();
            if(SpriteCounter > 0.3) {
                Sprite++;
                SpriteCounter = 0;
            }
            hitbox.setLocation(getX(),getY());
        } else {
            Texture = Down.get(0);
        }
    }

    public Hitbox getHitbox() {
        return hitbox;
    }
}