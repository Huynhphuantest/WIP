package AObject.ATile;

import AObject.Object;
import Texture.Assets;

import java.util.ArrayList;
import java.io.File;
import java.awt.image.BufferedImage;

public abstract class Tile extends Object {
    public static double DEFAULT_SIZE = 64;
    protected static ArrayList<Tile> TileList = new ArrayList<>();
    protected static ArrayList<Decoration> DecorList = new ArrayList<>();
    private static ArrayList<Class<?>> autoTexture = new ArrayList<>();
    private static ArrayList<BufferedImage> savedTexture = new ArrayList<>();
    public Tile(double x, double y) {
        super(x*DEFAULT_SIZE,y*DEFAULT_SIZE,DEFAULT_SIZE,DEFAULT_SIZE);
        Class<?> clazz = this.getClass().asSubclass(this.getClass());
        if(!autoTexture.contains(clazz)) {
            autoTexture.add(clazz);
            String name = clazz.getSimpleName();
            name = name.substring(0,name.length()-1);
            System.out.println("Tile/"+name+"/"+clazz.getSimpleName()+".png");
            //
            if(new File("Texture/Tile/"+name+"/"+clazz.getSimpleName()+".png").exists()) {
                savedTexture.add(Assets.LoadTile(name+"/"+clazz.getSimpleName()));
            }
        }
        Texture = savedTexture.get(autoTexture.indexOf(clazz));
        
        if(!Temporary && !(this instanceof Decoration)) {
            TileList.add(this);
        }
        if(!Temporary && this instanceof Decoration) {
            DecorList.add((Decoration)this);
        }
    }
    public static void updateAll( ) {
        
    }
    public static void updateAllB( ) {
        
    }
    public static void renderAll(java.awt.Graphics g) {
        for(Tile e : TileList) {
            if(!e.Loaded) {
                continue;
            }
            e.render(g);
        }
    }
    public static void renderAllB(java.awt.Graphics g) {
        for(Decoration e : DecorList) {
            if(!e.Loaded) {
                continue;
            }
            if(e.getShadow()!=null) {
                drawImage(
                    g,
                    e.getShadow(),
                    e.getX()+24.00,
                    e.getY()+e.getHeight()*0.28,
                    e.getWidth()*1.45,
                    e.getHeight()*1.45
                );
                g.setColor(new java.awt.Color(0,0,0,81));
            }
            e.render(g);
        }
    }
    public void render(java.awt.Graphics g) {
        g.drawImage(
            Texture,
            (int)getX(),
            (int)getY(),
            (int)getWidth(),
            (int)getHeight(),
            null
        );
    }
    public static ArrayList<Tile> getTileList() {
        return TileList;
    }
    public static ArrayList<Decoration> getDecorList() {
        return DecorList;
    }
}