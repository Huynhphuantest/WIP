package AObject.ATile.Natural;
import AObject.ATile.Tile;
import AObject.ATile.Natural.Decoration.*;
import java.util.Random;
public class Grass0 extends Tile {
    public Grass0(double x, double y) {
        super(x,y);
        Random rd = new Random();
        int r = rd.nextInt(10);
        if(r == 0) {
            new Grass1(x,y);
        }
        else if(r == 1) {
            new Grass2(x,y);
        }
        else if(r == 2) {
            new Grass3(x,y);
        }
        if(r < 3) {
            remove();
        }
        //130
        int d = rd.nextInt(230);
        if(d <= 15) {
            new Tree0(x,y);
        }
        if(d == 20) {
            new Tree3(x,y);
        }
    }
}