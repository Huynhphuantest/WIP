package AObject.ATile.Natural;
import AObject.ATile.Tile;
public class Grass1 extends Tile {
    public Grass1(double x, double y) {
        super(x,y);
    }
}