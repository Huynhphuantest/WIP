package AObject.ATile.Natural;
import AObject.ATile.Tile;
public class Grass3 extends Tile {
    public Grass3(double x, double y) {
        super(x,y);
    }
}