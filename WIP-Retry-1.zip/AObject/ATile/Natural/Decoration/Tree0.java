package AObject.ATile.Natural.Decoration;
import AObject.ATile.Decoration;
public class Tree0 extends Decoration {
    public Tree0(double x, double y) {
        super(x,y,true);
        width *= 2;
        height *= 2;
    }
}