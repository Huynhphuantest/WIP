package AObject.ATile.Natural.Decoration;
import AObject.ATile.Decoration;
import Texture.Assets;
import java.awt.image.BufferedImage;
public class Tree3 extends Decoration {
    private static final BufferedImage ThisShadow = AUtility.Util.rotate(Assets.LoadEntity("Shade/Shade"));
    private static final BufferedImage JumpScare = Assets.LoadEntity("Shade/GetShadedLol");
    private double Red;
    private boolean Booed;
    public Tree3(double x, double y) {
        super(x,y,false);
        width *= 2;
        height *= 2;
        Booed = false;
    }
    public void render(java.awt.Graphics g) {
        if(!Booed) {
            super.render(g);
        }
        if(intersects(AObject.AEntity.Neutral.Player.player.getHitbox()) && !Booed) {
            AObject.AEntity.Neutral.Player.player.getAttacked(10);
            Red = 255;
            Booed = true;
            ShadowTexture = null;
        }
        if(Booed) {
            renderLast(() -> {
                if(Red > 0) {
                    g.setColor(new java.awt.Color((int)Red,0,0,200));
                    g.fillRect(0,0,1440,992);
                    Red-=0.2;
                    if(Red < 122) {
                        remove();
                        Booed = false;
                    }
                }
            },3);
        }
    }
}