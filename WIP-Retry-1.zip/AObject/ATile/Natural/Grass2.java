package AObject.ATile.Natural;
import AObject.ATile.Tile;
public class Grass2 extends Tile {
    public Grass2(double x, double y) {
        super(x,y);
    }
}