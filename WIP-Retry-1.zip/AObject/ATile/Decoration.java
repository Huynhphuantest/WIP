package AObject.ATile;

import AObject.Hitbox;

import java.util.ArrayList;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;

public class Decoration extends Tile {
    protected boolean Shadow;
    protected BufferedImage ShadowTexture;
    private static ArrayList<Class<?>> autoTexture = new ArrayList<>();
    private static ArrayList<BufferedImage> savedTexture = new ArrayList<>(); 
    public Decoration(double x, double y, boolean Shadow) {
        super(x,y);
        if(Shadow) {
            if(!autoTexture.contains(this.getClass())) {
                autoTexture.add(this.getClass());
                savedTexture.add(addShadow(this));
            }
            ShadowTexture = savedTexture.get(autoTexture.indexOf(this.getClass()));
        }
    }

    public static BufferedImage addShadow(Decoration e) {
        double angle = 120;
        BufferedImage bimg = e.Texture;
        double 
            sin = Math.abs(Math.sin(Math.toRadians(angle))),
            cos = Math.abs(Math.cos(Math.toRadians(angle)));
        double 
            w = bimg.getWidth(),
            h = bimg.getHeight(),
            neww = (int) Math.floor(w*cos + h*sin),
            newh = (int) Math.floor(h*cos + w*sin);
        BufferedImage rotated = new BufferedImage((int)(neww), (int)(newh), bimg.getType());
        Graphics2D graphic = rotated.createGraphics();
        graphic.translate((neww-w)/2, (newh-h)/2);
        graphic.rotate(Math.toRadians(angle), w/2, h/2);
        graphic.drawRenderedImage(bimg, null);
        graphic.dispose();
        for(int i = 0; i < rotated.getHeight(); i++) {
            for(int j = 0; j < rotated.getWidth(); j++) {
                if(rotated.getRGB(i,j) != 0) {
                    rotated.setRGB(i,j,new java.awt.Color(0,0,0,142).getRGB());
                }
            }
        }
        return rotated;
        //Credits : https://stackoverflow.com/users/4455670/vinz
    }

    public BufferedImage getShadow() {
        return ShadowTexture;
    }
    public boolean intersects(Hitbox Target) {
        return Target.intersects(
            new java.awt.Rectangle(
                (int)(x-AObject.AEntity.Neutral.Player.player.getOffsetX()),
                (int)(y-AObject.AEntity.Neutral.Player.player.getOffsetY()),
                (int)width,
                (int)height
            )
        );
    }
}