package AObject.ASkill.Active;

import AObject.ASkill.Skill;
import AObject.AEntity.Creature;

public class Dash extends Skill {
    private double OwnerSpeed;
    public Dash(Creature c) {
        super(2,c);
        OwnerSpeed = Owner.getSpeed();
    }
    public void awake() {
        Owner.setSpeed(Owner.getSpeed()*(Amplifier*0.7+10));
        Manager.Time.invoke(
            () -> {
                Owner.setSpeed(OwnerSpeed);
            },0.2 
        );
    }
}