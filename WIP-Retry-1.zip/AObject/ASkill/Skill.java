package AObject.ASkill;

import AObject.AEntity.Creature;
    
import java.util.ArrayList;

public abstract class Skill {
    protected double Cooldown;
    protected boolean Cooling;
    protected Creature Owner;
    protected double Amplifier;
    protected static ArrayList<Skill> SkillList = new ArrayList<>();
    public Skill(double Cooldown, Creature Owner) {
        Cooling = false;
        this.Cooldown = Cooldown;
        this.Owner = Owner;
        Amplifier = 1;
        SkillList.add(this);
    }
    public void use() {
        if(!Cooling) {
            awake();
            Cooling = true;
            Manager.Time.invoke(
              () -> {
                  Cooling = false;
              }, Cooldown
            );
        }
    }
    public abstract void awake();

    public void setAmplifier(double newAmplifier) {
        this.Amplifier = newAmplifier;
    }
    public double getAmplifier() {
        return Amplifier;
    }
    public void updateAmplifier() {};
}